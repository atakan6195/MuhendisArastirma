package com.example.muhendisarastirma

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.JsonObject
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    // Railway/Render/Fly.io vb. backend adresini buraya yaz.
    // Örn: https://muhendis-arastirma-production.up.railway.app
    private val backendBaseUrl = "https://YOUR-BACKEND.example.com"

    private lateinit var imagePreview: ImageView
    private lateinit var promptEdit: EditText
    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var modeGroup: RadioGroup
    private lateinit var pdfButton: View

    private var selectedImageUri: Uri? = null
    private var cameraUri: Uri? = null
    private var lastResearchText: String = ""

    private val http = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) setImage(uri)
    }

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) setImage(cameraUri!!)
    }

    private val requestCameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else toast("Kamera izni verilmedi.")
    }

    private val createPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportResearchToPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imagePreview = findViewById(R.id.imagePreview)
        promptEdit = findViewById(R.id.editPrompt)
        progress = findViewById(R.id.progress)
        statusText = findViewById(R.id.statusText)
        resultText = findViewById(R.id.resultText)
        modeGroup = findViewById(R.id.researchMode)
        pdfButton = findViewById(R.id.buttonPdf)

        findViewById<View>(R.id.buttonGallery).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.buttonCamera).setOnClickListener { openCamera() }
        findViewById<View>(R.id.buttonResearch).setOnClickListener { startResearch() }
        pdfButton.setOnClickListener { startPdfExport() }
        pdfButton.isEnabled = false
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCamera()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraUri = uri
        takePicture.launch(uri)
    }

    private fun setImage(uri: Uri) {
        selectedImageUri = uri
        imagePreview.setImageURI(uri)
        imagePreview.visibility = View.VISIBLE
    }

    private fun selectedMode(): String = when (modeGroup.checkedRadioButtonId) {
        R.id.modePatent -> "patent"
        R.id.modeDocs -> "documents"
        R.id.modeGeneral -> "general"
        else -> "all"
    }

    private fun selectedModeLabel(): String = when (selectedMode()) {
        "patent" -> "Patent ağırlıklı"
        "documents" -> "Teknik doküman / standart / katalog ağırlıklı"
        "general" -> "Genel teknik araştırma"
        else -> "Tam araştırma: web + patent + teknik doküman + üretici"
    }

    private fun startResearch() {
        val text = promptEdit.text?.toString()?.trim().orEmpty()
        if (text.isBlank() && selectedImageUri == null) {
            toast("En az bir fotoğraf veya araştırma metni ekle.")
            return
        }
        if (backendBaseUrl.contains("YOUR-BACKEND")) {
            toast("Önce MainActivity.kt içindeki backendBaseUrl değerini ayarla.")
            return
        }

        setLoading(true)
        statusText.text = "Fotoğraf ve açıklama hazırlanıyor…"
        resultText.text = ""
        lastResearchText = ""
        pdfButton.isEnabled = false

        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("prompt", text)
            .addFormDataPart("mode", selectedMode())

        selectedImageUri?.let { uri ->
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) {
                val name = getFileName(uri) ?: "image.jpg"
                body.addFormDataPart("image", name, bytes.toRequestBody("image/jpeg".toMediaTypeOrNull()))
            }
        }

        val request = Request.Builder()
            .url("${backendBaseUrl.trimEnd('/')}/api/research")
            .post(body.build())
            .build()

        statusText.text = "Yapay zekâ web, patent ve teknik kaynakları araştırıyor…"
        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    setLoading(false)
                    statusText.text = "Bağlantı hatası: ${e.message}"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty()
                runOnUiThread {
                    setLoading(false)
                    if (!response.isSuccessful) {
                        statusText.text = "Sunucu hatası (${response.code})"
                        resultText.text = raw
                    } else {
                        statusText.text = "Araştırma tamamlandı. Sonucu PDF olarak da kaydedebilirsin."
                        lastResearchText = formatResult(raw)
                        resultText.text = lastResearchText
                        pdfButton.isEnabled = lastResearchText.isNotBlank()
                    }
                }
            }
        })
    }

    private fun formatResult(raw: String): String {
        return try {
            val root = Gson().fromJson(raw, JsonObject::class.java)
            val r = root.getAsJsonObject("research") ?: return raw
            val sb = StringBuilder()

            fun section(title: String, body: String?) {
                if (!body.isNullOrBlank()) sb.append("\n$title\n${"─".repeat(title.length)}\n$body\n")
            }

            section("KISA SONUÇ", r.get("summary")?.asString)
            section("TESPİT EDİLEN PARÇA / MEKANİZMA", r.get("identified_object")?.asString)

            r.getAsJsonArray("search_queries")?.let { arr ->
                sb.append("\nARAŞTIRILAN SORGULAR\n────────────────────\n")
                arr.forEach { sb.append("• ${it.asString}\n") }
            }

            fun appendItems(key: String, title: String) {
                val arr = r.getAsJsonArray(key) ?: return
                if (arr.size() == 0) return
                sb.append("\n$title\n${"─".repeat(title.length)}\n")
                arr.forEachIndexed { i, el ->
                    val o = el.asJsonObject
                    sb.append("${i + 1}. ${o.get("title")?.asString ?: "Kaynak"}\n")
                    o.get("type")?.asString?.let { sb.append("Tür: $it\n") }
                    o.get("summary")?.asString?.let { sb.append("$it\n") }
                    o.get("why_relevant")?.asString?.let { sb.append("Neden önemli: $it\n") }
                    o.get("url")?.asString?.let { sb.append("Kaynak: $it\n") }
                    sb.append("\n")
                }
            }

            appendItems("patents", "PATENTLER")
            appendItems("documents", "TEKNİK DOKÜMANLAR / KATALOGLAR")
            appendItems("findings", "DİĞER BULGULAR")

            r.getAsJsonArray("engineering_notes")?.let { arr ->
                if (arr.size() > 0) {
                    sb.append("\nMÜHENDİSLİK NOTLARI\n───────────────────\n")
                    arr.forEach { sb.append("• ${it.asString}\n") }
                }
            }

            r.getAsJsonArray("next_steps")?.let { arr ->
                if (arr.size() > 0) {
                    sb.append("\nSONRAKİ ARAŞTIRMA ADIMLARI\n─────────────────────────\n")
                    arr.forEach { sb.append("• ${it.asString}\n") }
                }
            }
            sb.toString().trim()
        } catch (_: Exception) {
            raw
        }
    }

    private fun startPdfExport() {
        if (lastResearchText.isBlank()) {
            toast("Önce bir araştırma tamamla.")
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
        createPdf.launch("Muhendis_Arastirma_$stamp.pdf")
    }

    private fun exportResearchToPdf(uri: Uri) {
        try {
            val document = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 42f
            val contentWidth = pageWidth - (margin * 2)
            val bottomMargin = 45f

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 20f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 12.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f }
            val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f }

            var pageNumber = 1
            var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas = page.canvas
            var y = margin

            fun finishAndNewPage() {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = margin
                canvas.drawText("Mühendis Araştırma Raporu", margin, y, smallPaint)
                canvas.drawText("Sayfa $pageNumber", pageWidth - margin - 45f, y, smallPaint)
                y += 22f
            }

            fun ensureSpace(height: Float) {
                if (y + height > pageHeight - bottomMargin) finishAndNewPage()
            }

            fun drawWrapped(text: String, paint: Paint, gapAfter: Float = 4f) {
                val lineHeight = paint.textSize * 1.45f
                wrapText(text, paint, contentWidth).forEach { line ->
                    ensureSpace(lineHeight)
                    if (line.isNotEmpty()) canvas.drawText(line, margin, y, paint)
                    y += lineHeight
                }
                y += gapAfter
            }

            canvas.drawText("Mühendis Araştırma Raporu", margin, y, titlePaint)
            y += 30f
            val date = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
            drawWrapped("Oluşturulma: $date", smallPaint, 3f)
            drawWrapped("Araştırma modu: ${selectedModeLabel()}", smallPaint, 10f)

            val userPrompt = promptEdit.text?.toString()?.trim().orEmpty()
            if (userPrompt.isNotBlank()) {
                ensureSpace(25f)
                canvas.drawText("ARAŞTIRMA NOTU", margin, y, headingPaint)
                y += 19f
                drawWrapped(userPrompt, bodyPaint, 10f)
            }

            selectedImageUri?.let { imageUri ->
                try {
                    contentResolver.openInputStream(imageUri)?.use { input ->
                        val bitmap = BitmapFactory.decodeStream(input)
                        if (bitmap != null) {
                            val maxW = contentWidth
                            val maxH = 250f
                            val scale = min(maxW / bitmap.width.toFloat(), maxH / bitmap.height.toFloat())
                            val w = bitmap.width * scale
                            val h = bitmap.height * scale
                            ensureSpace(h + 35f)
                            canvas.drawText("ARAŞTIRMA GÖRSELİ", margin, y, headingPaint)
                            y += 18f
                            val dst = android.graphics.RectF(margin, y, margin + w, y + h)
                            canvas.drawBitmap(bitmap, null, dst, null)
                            y += h + 14f
                            bitmap.recycle()
                        }
                    }
                } catch (_: Exception) {
                    // Görsel eklenemese de metin raporu oluşturulmaya devam eder.
                }
            }

            ensureSpace(30f)
            canvas.drawText("ARAŞTIRMA SONUCU", margin, y, headingPaint)
            y += 20f
            drawWrapped(lastResearchText, bodyPaint, 0f)

            canvas.drawText("Sayfa $pageNumber", pageWidth - margin - 45f, pageHeight - 20f, smallPaint)
            document.finishPage(page)

            contentResolver.openOutputStream(uri)?.use { output -> document.writeTo(output) }
                ?: throw IOException("PDF dosyası açılamadı.")
            document.close()
            toast("PDF raporu başarıyla kaydedildi.")
        } catch (e: Exception) {
            toast("PDF oluşturulamadı: ${e.message}")
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        text.replace("\r", "").split("\n").forEach { paragraph ->
            if (paragraph.isEmpty()) {
                result.add("")
                return@forEach
            }
            var remaining = paragraph
            while (remaining.isNotEmpty()) {
                var count = paint.breakText(remaining, true, maxWidth, null)
                if (count <= 0) count = 1
                if (count < remaining.length) {
                    val candidate = remaining.substring(0, count)
                    val lastSpace = candidate.lastIndexOf(' ')
                    if (lastSpace > 0) count = lastSpace
                }
                val line = remaining.substring(0, count).trimEnd()
                result.add(line)
                remaining = remaining.substring(count).trimStart()
            }
        }
        return result
    }

    private fun getFileName(uri: Uri): String? {
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
            }
        }
        return uri.lastPathSegment
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        findViewById<View>(R.id.buttonResearch).isEnabled = !loading
        if (loading) pdfButton.isEnabled = false else if (lastResearchText.isNotBlank()) pdfButton.isEnabled = true
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
